<?php
$lang->branch->common = '分支';
$lang->branch->manage = '分支管理';
$lang->branch->delete = '分支删除';

$lang->branch->manageTitle = '%s管理';
$lang->branch->all         = '所有';

$lang->branch->confirmDelete = '@branch@删除，会影响关联该@branch@的需求、模块、计划、发布、Bug、用例等等，请慎重考虑。是否删除该@branch@';
