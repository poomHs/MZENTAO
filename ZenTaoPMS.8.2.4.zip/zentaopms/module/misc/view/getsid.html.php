<?php include dirname(dirname(dirname(__FILE__))) . '/common/view/header.html.php';?>
Output from the main view file: <?php echo $sid;?>
