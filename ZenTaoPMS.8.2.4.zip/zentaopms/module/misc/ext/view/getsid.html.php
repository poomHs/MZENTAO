<?php include '../../view/getsid.html.php';?> <br />
output from the ext view file: <?php echo $test;?><br  />
ext config:<?php a($config->misc);?>
ext lang:<?php a($lang->misc);?>
